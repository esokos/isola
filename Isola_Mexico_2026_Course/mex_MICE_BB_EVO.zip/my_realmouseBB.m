close all
clear all

% Detection of Mice I and II on BB record
% Jiri Zahradnik, summer 2026


set(0, 'DefaultAxesFontName', 'Arial'); % Sets font for axes, labels, titles
set(0, 'DefaultTextFontName', 'Arial'); % Sets font for other text objects
set(0, 'DefaultAxesFontSize', 14);      % Sets default axes font size
set(0, 'DefaultTextFontSize', 16);      % Sets default general text size
set(0,'DefaultFigureColormap',feval('jet')); %  Sets default colormap


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%           READING REAL_BB RECORD (='SIGNAL' DATA) 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


[C] = textread('Invert.dat','%f','commentstyle','matlab'); 
endtime=C(1)
pwavetime=C(2)
swavetime=C(3)
timlim=C(4)
%perctaper=C(5)

[D] = textread('Statinfo.dat','%s' ,'commentstyle','matlab') % comments start with % 
sigfilename=D{1}
insfilename=D{2}

%compstr=zeros(4,1);
compstr=['t','N','E','Z'];

%Fixed options
perctaper=0.05 % the left and right "end" has 5% width of total length on each end 
keypoly=0 % no polynomial fit to mice


% Single-station real record %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 3-comp RECORD to be analyzed (t,N,E,Z)
A = load(sigfilename); 
dt=A(2,1)-A(1,1) % column 1 of A is time in seconds; starting at 0
totlen=(length(A)-1)*dt

if(endtime>totlen)
    disp('WARNING: endtime>totlen; shorten endtime')
    pause
end

if swavetime-timlim <=0 | swavetime-timlim >= endtime
    disp('WARNING: need to modify timlim')
    pause
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%           READING INSTRUMENT DATA  and calculating synthtic mice
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fid = fopen(insfilename,'r');
Z = str2num(fgetl(fid)) 
P = str2num(fgetl(fid)) 
K = str2num(fgetl(fid))
count2ground= str2num(fgetl(fid))
instTcorner= str2num(fgetl(fid))
  if(instTcorner == 0)
    disp('WARNING: check instTcorner, long-period instrumental corner (in seconds)')
    pause
  end
fclose(fid);


G = zpk(Z,P,K); % dynamic system; an object 

   figure    % Bode diagram; here plotted from 0.01 to 30 Hz
   wmin=2*pi * 0.01;wmax= 2*pi * 30; % w must be in radians/sec
   w={wmin,wmax};
   h = bodeplot(G,w);     % Response in form of Bode diagram
    setoptions(h,'MagUnits','abs','FreqUnits','Hz');



% Step response exists always from time 0; here defined with step dt
  % for STEP, first t MUST be 0, dt is the time step of real record; right limit is our choice
  %tlft=0; trgh=endtime-swavetime
  tlft=0; trgh=round((endtime-swavetime)/dt)*dt; % for case that (...) is not integer, here rounded
  t=[tlft:dt:trgh];
  [y,t] = step(G,t); % response of BB to step in velocity;
                     % = response of integrated BB to step in displacement
                     
% Padding zero into the  t and y vectors and from 0 to swavetime
   %t=0:dt:endtime;
   tlft=0;trgh=round(endtime/dt)*dt;
   t=[tlft:dt:trgh];
   numzeros=round(swavetime/dt);    
   y=[zeros(numzeros,1);y]; 
  
   
    if(keypoly==1)
% %% POLYNOM 
poly_n=100;
[p,S] = polyfit(t',y,poly_n); 
[y_poly,delta] = polyval(p,t,S);
y=y_poly';
% %size(y)
    else
    end
     maxy=max(y);  
     y=y/maxy;   % Normalization 
   
   figure
   plot(t,y)
   xlabel('time (s)')
   title('Step response') % Normalized step response  
    
   y_int = cumsum(y,1) .* dt;  % Normalized synthetic Mouse II on integrated BB = = Step response integrated once
                               % = response of integrated BB to step in velocity 
    
   if(keypoly==1)
   %%% POLYNOM 
   poly_n=100;
   [p,S] = polyfit(t',y_int,poly_n); 
   [y_int_poly,delta] = polyval(p,t,S);
   y_int=y_int_poly';
   %size(y_int)
   else
   end
   
   maxy_int=max(y_int); 
   y_int=y_int./maxy_int;
   
   figure
   plot(t,y_int)
    xlabel('time (s)')
    title('Normalized synth. Mouse II')
   
   y_2int = cumsum(y_int,1)*dt; % Normalized synthetic Mouse I on integrated BB = Step response integrated twice 
                                % = response of integrated BB to step in acceleration
                                % See Fig. 3 of Zahradnik & Plesinger, BSSA 2010.
   if(keypoly==1)
   %%% POLYNOM 
   poly_n=100;
   [p,S] = polyfit(t',y_2int,poly_n); 
   [y_2int_poly,delta] = polyval(p,t,S);
   y_2int=y_2int_poly';
   else
   end
   maxy_2int=max(y_2int); 
   y_2int=y_2int/maxy_2int;
   
   figure
   plot(t,y_2int) 
   xlabel('time (s)')
   title ('Normalized synth. Mouse I')


   datasyn2=y_int; % synthetic mouse II on integrated BB, column vector, step dt
   datasyn1=y_2int; % synthetic mouse I on integrated BB, column vector, step dt

% %%%%%%%%%%%
 d1=datasyn1; d2=datasyn2; % synthetic mouse I and II  
% (renamed, because later in inversion we need d1 and d2)
% %%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% PROCESSING and INVERTING REAL DATA in a loop over components 
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

disp(['Best-fit model of record: ',  sigfilename])  
disp('Shift in multiples of dt, Mouse I and II in units given by valmax, presently m/s2')  

fid2=fopen('MouseFit.dat', 'w'); % write at the end of next loop
fprintf(fid2,'%6s %',['Best-fit model of record: ',  sigfilename ]);
fprintf(fid2,'\n');
fprintf(fid2,'%6s %','Shift in multiples of dt, Mouse I and II in units given by valmax, presently m/s2');  

valmax=zeros(4,1);   %pre-allocating for maximumum of components; column 2,3,4 = comp N,E,Z
truemax1=zeros(4,1); %pre-allocating for size of Mouse I on components
truemax2=zeros(4,1); %pre-allocating for size of Mouse II on components

 for icolumn=2:1:4       % SUPERLOOP OVER COMPONENTS of SIGNAL (=REAL RECORD) 2,3,4 = N,E,Z
 
ilft=1; irgh=round(endtime/dt)  + 1; % this is index, not last time, therefore "+ 1"
 x=A(ilft:irgh,1);       % time  from 0 to endtime, step dt
 %x=0:dt:endtime +dt;    % time
y=A(ilft:irgh,icolumn); % THREE  components; icolumn = 2,3,4 
%%%%%%%%%%%%%%% y=A(ilft:irgh,icomp ); %                  
 L=length(y); 
tt =  (1:L)' ;           % 1D column vector of indices for time vector tt (whole record!)

% Demean 
% Mouse is assumed to NOT occur between t=0 and P arrival time somewhat reduced by timlim  
% swavetime-timlim is "pre-event noise window" for demean
L2=round((pwavetime-0.1*pwavetime)/dt)  ;   % reserve 10% to define noise window surely before P
y=y-mean(y(1:L2)); 
%mean calculated from noise window, but mean removed from whole records

% Detrend of demeaned record
%detrend method 1
 L3=round(swavetime/dt) + 1;
 BP=[1,L2,L3,L];
% y = detrend(y,'linear',BP);
%detrend method 2
%trend calculated from noise window; trend removed from whole records
 p = polyfit(tt(1:L2), y(1:L2), 1);   
 trend = polyval(p, tt);             % extend trend over whole record (subtract from entire trace)
%y = y  - trend;          % if commented, then detrend suppressed, ONLY DEMEAN APPLIED
% detrended not used due to poor numerical experience 

% Plotting original records
figure (20)
specstring = strcat('SIGNAL',' ',compstr(icolumn));
plot(x,y,'DisplayName',specstring,'LineWidth',3)
xlabel('time (s)')
ylabel('BB record (count)')
title ('Original record, non-normalized') 
legend
hold on


% % %Normalization of a particular COMPONENT (in a loop) after demean, BEFORE integration
% % [out,ii]  = max(abs(y)); % normalization IS NOT NEEDED (IN PRINCIPLE) but we use it
% % % missing normalization affect neither shift1,2, nor  VR ; 
% % % it only affectes coeff1,2 (but with their  correct relative coef1/coef2 proportion) 
% % y=y/out;   % so this can be omitted, but :... 
% % %%%%% IF normaliz is present then coef1,2 are comparable with peak
% % %dataobs=y; % real BB record (NOT integrated) )with or without mouse




% % % % Integration of real record (demean and detrend always before integration)  
y_int = cumsum(y,1) .* dt; % integrated BB, called "raw displacement" ; units = count.s 



%Normalization of a particular COMPONENT (in a loop) AFTER INTEGRATION
% ATTENTION: Here we normalize after integration. This is different compared to SM records inversion. 
[out,ii]  = max(abs(y_int)); 

%FIXED OPTIONS of VALMAX; 
%'out' is the normalization constant; unit = count.s (=count x second) 
% count2ground has unit = (m/s)/count
%valmax(icolumn)=out * count2ground;  % unit = m
valmax(icolumn)=out * count2ground * 4 * pi ^2 * (1 /instTcorner) ^2; % unit = m/s^2
%valmax(icolumn)=out * count2ground * 4 * pi ^2 * (1 /instTcorner) ^2 / 10 ; % unit = radian
% The latter option has sense for tilt on horizontals only, 10 is "gravity" in m/s2, then valmax is dimensionless (radians)

y_int=y_int/out;   %unit = 1 
dataobs=y_int; % real "signal" = signal + mouse; normalized integrated BB output

% TUKEY's window
% this is not needed; later we ignore the left and right end; no need to taper them
%Matlab2024b has no function "taper" but has tukeywin
%%%%% dataobs=dataobs .* tukeywin(length(dataobs),2*perctaper); %at each end, taper width is perctaper (now fixed at 0.05)
% tukeywin needs specification of DOUBLE length 2*perctaper (now fixed at % 0.1 = 10% of total)
  
%Plotting total integrated seismo (no ends cuts)
% figure (32)
% specstring = strcat('SIGNAL',' ',compstr(icolumn));
% plot(x,dataobs,'DisplayName',specstring,'LineWidth',3)
% xlabel('time (s)')
% title ('Integrated record, normalized') % differs from SIGNAL if taper is applied
% legend
% hold on
% saveas(figure(32),[pwd '/Mice_plots/Integrated_Record.png']);



%%%%%%%% Plotting total spectra (no ends cuts)
%      figure (33)
%      [freq,sp] = my_tapered_spectrum(dt,dataobs);
%      %sp=smooth(sp);
%      spSIGplot=sp;    %   /max(sp);  % /sp(1,1); %
%      specstring = strcat('SIGNAL',' ',compstr(icolumn));
%      loglog(freq,spSIGplot, 'DisplayName',specstring,'LineWidth',3);
%       xlabel('frequency (Hz)')
%       title('Spectrum of integrated record ');
%       legend
% %       xlim([1e-3 1e1])
% %       ylim([1e-4 1e2])
%     hold on
%saveas(figure(33),[pwd '/Mice_plots/Spectrum_Integrated_Record.png']);
%hold off


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%              Inversion will ignore left and rigt data ends
%     Spectra are affected by the steps but we taper them equally
%     after aligning real and fitted mouse (see function my_tapered_spectrum)
%     I.e. spectral comparison is reasonable in case of good time-domain fit.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



numpo=size(dataobs,1); % real mouse in interval [0,endtime]
taperlen= round(perctaper*numpo); % left and right "ends" have width of 5% of total  (see fixed perctaper=0.05)
% In these "ends" we do not fit data and mice. 
d=dataobs(taperlen:numpo-taperlen);
t2=t(taperlen:numpo-taperlen);

% %%%%%%%%%%%
% d1=datasyn1; d2=datasyn2; % synthetic mouse I and II in same interval 
% %%%%%%%%%%%

   %numpo=size(d,1); %%%%%%%%%%%% ATTENTION, not size(d)
   % is size(d), then if (...) = [1,0] instead of 1
   j=0;
   
   % Two (nested) inner loops over shifts for mouse I and II 
   %(for each time shift we do the LSQ inversion for amplitude coefficients = multiples of unit Mouse I and II)
    isetlim=ceil(timlim/dt); %%%   timlim is read from Invert.dat
    %ish1<0...shift to left, missing points (creating zeros) at right end
    loopstep=floor(isetlim/50); % To make process faster; step is not 1, but step = 2% of isetlim
   if(loopstep<1) 
       disp('PROBLEM: loopstep')
       pause
   end
   
%    %Preallocation for two loops both from -setlim to +isetlim with step loopstep:
%    % expected number of passes through one loop 
%    expected_numpass=  ceil((isetlim - (- isetlim))/loopstep)  + 1;
%    %expected number of passes through both loops 
%    expected_numpass= expected_numpass ^2
   
%   Preallocation 
   %true number of loop passes
   loopvals=-isetlim:loopstep:isetlim;
   numpass=numel(loopvals) ^ 2;
   
   indsave=zeros(numpass,2);
   cofsave=zeros(numpass,2);
   missave=zeros(numpass,1); % Attention, not zeros(numpass) !!  

   for ish1= -isetlim :loopstep: isetlim  % shift of synt mouse I
     d1sh=zeros(numpo,1); 
        for i=1:numpo
            if (i-ish1)>0 && (i-ish1)<=numpo == 1 
            d1sh(i)=d1(i-ish1);
           end
        end

         d1sh=d1sh(taperlen:numpo-taperlen);

   % Loop for ish2 is inside the loop for ish1    
   for ish2= -isetlim :loopstep : isetlim % shift of synt mouse II
      j=j+1; 
         d2sh=zeros(numpo,1);
            for i=1:numpo
              if (i-ish2>0) && (i-ish2)<=numpo == 1
                d2sh(i)=d2(i-ish2); %!! Commenting this line suppresses mouse II; only mouse I is modeled; not much tested
              end
            end
         
          d2sh=d2sh(taperlen:numpo-taperlen);

          GG=[d1sh,d2sh]; % 2 column vectors
           cof=GG\d; % model paramters; coefficients currently calculated; cof is array 2x1 
           indsave(j,1)=ish1;
           indsave(j,2)=ish2; % shift indices accumulated, saved

           cofsave(j,1)= cof(1,1); % coefficients (1x2) accumulated, saved
           cofsave(j,2)= cof(2,1);
           
           daprox= GG * cof; % 1 column vector to approximate d in LSQ sense 
%         %  plot(t,daprox) % a possible plotting of all (!!!) models throughout the double loop  
           misfit=norm(daprox-d)/norm(d); % L2-norm misfit currently calculated, 1x1
           missave(j)=misfit; % misfit accumulated, saved


   end % end of loop over ish2
   end % end of loop over ish1
   
%   j % total number of passes through the nested loops


%missave is the saved misfit for the whole grid search; can be plotted (not tested)
%%%%% Detecting minimum misfit, i.e. the best mice shifts and their amplitude coefficients      
  
  [minmis,indmin]=min(missave);
  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Numeric output (screen and file) [within loop over components ]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% DE-normalization of the best-fit solution for a given column 2,3,4 (=component N,E,Z)
% cofsave: units = 1; valmax: unit = see fixed option, presently m/s2
    truemax1(icolumn)=cofsave(indmin,1) * valmax(icolumn); % Mouse I ;  %unit = presently m/s2
    truemax2(icolumn)=cofsave(indmin,2) * valmax(icolumn); % Mouse II;  %unit = presently m/s2


%header 1
 fprintf(fid2,'\n');
 fprintf(fid2,'%6s %','component');
 fprintf(fid2,'%6s %', compstr(icolumn));
 fprintf(fid2,'\n');
  fprintf(     '\n');
 fprintf(     '%6s %','component');
 fprintf(     '%6s %', compstr(icolumn));
 fprintf(     '\n');
%header 2
header_fmt = '%10s %10s %10s %15s %15s %15s\n';
name1= 'iter.no.';
name2= 'shift1';
name3= 'shift2';
name4= 'mouse1';
name5= 'mouse2';
name6= 'misfit';
fprintf(fid2, header_fmt, name1, name2, name3, name4, name5, name6); % in file 
fprintf(      header_fmt, name1, name2, name3, name4, name5, name6); % on screen
%values
data_fmt = '%10.f %10.f %10.f %15.6e %15.6e %15.6f\n';



% fprintf(      data_fmt, ...
%     indmin, indsave(indmin,1), indsave(indmin,2), ...
%     cofsave(indmin,1), cofsave(indmin,2), missave(indmin));
% fprintf(fid2, data_fmt, ...
%     indmin, indsave(indmin,1), indsave(indmin,2), ...
%     cofsave(indmin,1), cofsave(indmin,2), missave(indmin));

fprintf(      data_fmt, ...
    indmin, indsave(indmin,1), indsave(indmin,2), ...
    truemax1(icolumn), truemax2(icolumn), missave(indmin));
fprintf(fid2, data_fmt, ...
    indmin, indsave(indmin,1), indsave(indmin,2), ...
    truemax1(icolumn), truemax2(icolumn), missave(indmin));




    
  
%%%%% Evaluating the best model and plot it 

    d1sh=zeros(numpo,1); 
       indsh1=indsave(indmin,1); 
       for i=1:numpo
            if (i-indsh1)>0 && (i-indsh1)<=numpo == 1 
            d1sh(i)=d1(i-indsh1);
            end
        end
    d2sh=zeros(numpo,1); %%%%%%%%%%%% ATTENTION, not zeros(numpo) !!!
       indsh2=indsave(indmin,2); 
       for i=1:numpo
            if (i-indsh2)>0 && (i-indsh2)<=numpo == 1 %logical 1 = true
            d2sh(i)=d2(i-indsh2);
            end
       end
     
     d1sh=d1sh(taperlen:numpo-taperlen);
     d2sh=d2sh(taperlen:numpo-taperlen);
     

     GG=[d1sh,d2sh];
     cofbest=[cofsave(indmin,1),cofsave(indmin,2)];
     dbest= GG * cofbest';
     misfitbest=norm(dbest-d)/norm(d); % L2-norm misfit currently calculated, 1x1
  
 
   d1sh=d1sh * cofbest(1);
   d2sh=d2sh * cofbest(2);
   
   %FIGNUM=30;
   figure (30)
   % Disable expensive features
ax = gca;
ax.NextPlot = 'add';
ax.SortMethod = 'childorder';
% ax.XLimMode = 'manual';
% ax.YLimMode = 'manual';
% Pre-set limits if possible
 xlim([0 endtime])
% ylim([-1 1])

   
   hold on
   if(icolumn==2)
   xline(pwavetime, 'b','DisplayName','Pwavetime'); 
   xline(swavetime, 'g','DisplayName','Swavetime');  
   xline(swavetime-timlim, 'g','LineStyle','--','DisplayName','Search limit'); 
   xline(swavetime+timlim, 'g','LineStyle','--','DisplayName','Search limit'); 
   end

    specstring = strcat('SIGNAL',' ',compstr(icolumn));
    plot(t2,d, 'DisplayName',specstring);
    specstring = strcat('mouse1',' ',compstr(icolumn));
%    plot(t2,d1sh,'DisplayName',specstring)
    specstring = strcat('mouse2',' ',compstr(icolumn));
%    plot(t2,d2sh,'DisplayName',specstring)
    specstring = strcat('MOUSE',' ',compstr(icolumn));
    plot(t2,dbest,'DisplayName',specstring,'LineWidth',3)
   %legend ('Location', 'northwest')
   legend
   xlabel('time (s)')
   ylabel('norm. int. record (dimensionless)')
   title(['Modeling record: ', sigfilename])
   
   fname = ['Mice_Record_', sigfilename(1:end-4),'.png'];
   saveas(figure(30), fullfile(pwd, 'Mice_plots', fname));
   
   
   %%%%%%%% Spectra 
      [freq,sp]=my_tapered_spectrum(dt,d);
      %length(d)
      %[freq,sp]=my_tapered_spectrum(dt,d_int);
      spSIGplot=sp;    %   /max(sp);  % /sp(1,1); %
      figure (40)
      specstring = strcat('SIGNAL',' ',compstr(icolumn));
      loglog(freq,spSIGplot, 'DisplayName',specstring);
      hold on
      [freq,sp]=my_tapered_spectrum(dt,dbest);
      %length(dbest)
      %[freq,sp]=my_tapered_spectrum(dt,dbest_int);
      spMICEplot=sp;    %   /max(sp);  % /sp(1,1); %
      specstring = strcat('Mouse',' ',compstr(icolumn));
      loglog(freq,spMICEplot, 'DisplayName',specstring,'LineWidth',3);
      legend
      xlim ([1e-3, 1e0])
      ylim ([1e-4, 1e2])
      xlabel('frequency (Hz)')
      ylabel('spectrum of norm. int. record (s)')
      title (['Modeling spectrum: ', sigfilename])

      %Analyze where signal and mouse spectra of a given component differ
      % Increase continually freq and seek first point where sp of signal is > 10 * mouse
     nfreq=numel(freq);
     df=freq(2)-freq(1);
     for ifr= 1:1:nfreq
        if spSIGplot(ifr) > 10 .* spMICEplot(ifr) 
        %fprintf('Stopping at index %d\n', ifr);
        fprintf('Stopping at frequency %d\n', ifr*df);
        break;
        end
     end


% % %    %%%%%%%% Spectra after DIFFERENTIATION
% % %       differ_d = diff(d)/dt;
% % %       differ_dbest = diff(dbest)/dt;
% % %       
% % %       [freq,sp]=my_tapered_spectrum(dt,differ_d);
% % %       spSIGplot=sp;    %   /max(sp);  % /sp(1,1); %
% % %       figure (41)
% % %       specstring = strcat('SIGNAL',' ',compstr(icolumn));
% % %       loglog(freq,spSIGplot, 'DisplayName',specstring);
% % %       hold on
% % %       [freq,sp]=my_tapered_spectrum(dt,differ_dbest);
% % %       %length(dbest)
% % %       %[freq,sp]=my_tapered_spectrum(dt,dbest_int);
% % %       spMICEplot=sp;    %   /max(sp);  % /sp(1,1); %
% % %       specstring = strcat('Mouse',' ',compstr(icolumn));
% % %       loglog(freq,spMICEplot, 'DisplayName',specstring,'LineWidth',3);
% % %       legend
% % %       xlim ([1e-3, 1e0])
% % %       ylim ([1e-4, 1e2])
% % %       title (['Modeling spectrum after DIFFERENTIATION: ', sigfilename])

   
   %fprintf('\n')
   if abs(cofbest(1)) >= 3*abs(cofbest(2))
       msg1 = 'Mouse I is dominating (> 3-times) over Mouse II \n';
       fprintf(fid2,msg1);
       fprintf(     msg1);
       %disp('Mouse I is strongly (> 3-times) dominating')
     elseif abs(cofbest(2)) >= 3*abs(cofbest(1))
       msg3 = 'Mouse II is dominating (> 3-times) over Mouse I \n';
       fprintf(fid2,msg3);
       fprintf(     msg3);
       %disp('Mouse II is strongly (> 3-times) dominating')
   end

    if abs(indsh1)>=isetlim 
       msg2 = 'WARNING: shift of Mouse I reached limit, check timlim or swavetime\n';
       fprintf(fid2,msg2);
       fprintf(     msg2);
       %disp('WARNING: shift of Mouse I reached limit, check timlim or swavetime')
    end  
    if abs(indsh2)>=isetlim 
       msg4= 'WARNING: shift of Mouse II reached limit, check timlim or swavetime\n';
       fprintf(fid2,msg4);
       fprintf(     msg4);
       %disp('WARNING: shift of Mouse II reached limit, check timlim or swavetime')
    end
 
   if abs(cofbest(1)) <= 0.2 && abs(cofbest(2)) <= 0.2
       msg5 = 'No large mice found on this component (>= 0.2*dataobs); inversion may be wrong\n';
       fprintf(fid2,msg5);
       fprintf(     msg5);
   end
  
   if misfitbest > 0.5
       msg6 = 'WARNING: Misfit on this component is high, > 0.5, i.e. VR < 0.5; inversion may be wrong\n';
       fprintf(fid2,msg6);
       fprintf(     msg6);
   end

 
end    %%%%%%%   END OF SUPERLOOP OVER COMPONENTS of REAL RECORD (processing and inversion)
 fclose (fid2);
 
  
  
  
%  disp('Info: demean')
%  L2*dt

 
   fname = ['Mice_Record_', sigfilename(1:end-4),'.png'];
   saveas(figure(30), fullfile(pwd, 'Mice_plots', fname));
   fname = ['Mice_Spectrum_', sigfilename(1:end-4),'.png'];
   saveas(figure(40), fullfile(pwd, 'Mice_plots', fname));

   
      
src  = 'MouseFit.dat';
filen= ['Mice_Fit_', sigfilename(1:end-4),'.dat']; 
dest = fullfile('mice_plots', filen);
copyfile(src, dest);

src  = 'Invert.dat';
filen= ['Invert_', sigfilename(1:end-4),'.dat']; 
dest = fullfile('mice_plots', filen);
copyfile(src, dest);

src  = 'Statinfo.dat';
filen= ['Statinfo_', sigfilename(1:end-4),'.dat']; 
dest = fullfile('mice_plots', filen);
copyfile(src, dest);


 disp(' ')
 disp('Code terminated')
 
 
 
 
 
 
 function [freq,sp] = my_tapered_spectrum(dt,x)
      fs=1/dt;
      numpo=length(x);
      last=numpo; % FFT assumes x is of an EVEN  length;
      if mod(last,2) ~= 0; % if modulo us not equal 0, we have an ODD number 
      last=numpo-1;     % making an EVEN length
      end
      x=x(1:last);
      
      % TAPER used only for resulting spectra of records and synth mice
      x=x .* tukeywin(length(x),0.2); % tapering only for computation of spectrum
      % number is percentage of total legth; 0.2 is 20%, i.e., 10% at each end 
      % if taper width is very small, e.g. 0.001 = 0.1% then result is
      % almost as without taper ['without taper'= rectangural window]

      
      xdft = fft(x); 
      xdft = xdft(1:length(x)/2+1); %length(x) je pocet bodu x a take xdft
      freq = 0:fs/length(x):fs/2; % from 0 with step df=1/T=1/(Ndt) to Nyquist (1/(2dt)), all in Hz
      sp=(1/fs) * abs(xdft); % 1/fs= dt MULTIPLICATION BY DT IS A MUST
end
 
 
 
 
 