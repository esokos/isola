plane
12
12
25
1
0
Sources on a plane 
