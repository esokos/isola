G:\eq_venez_school_LF\crust1_nearepic_10.5_-68.5.cru
