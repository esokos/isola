gmtset FORMAT_GEO_MAP D  FONT_ANNOT_PRIMARY 12 FONT_ANNOT_SECONDARY 12 FONT_TITLE 14 FONT_LABEL 14
 
pscoast -R-68.49064/-65.77799/10.47158/10.70496  -JM1ch -G255/255/204 -Df -W0.7p -P -B0.5  -K -Slightblue -Lf-67.13/10.5716/10.59/20+l > timspc.ps
 
psxy -R  -JM1ch sources.gmt -Sd0.2c     -W1p   -K -O -G255/0/0 >> timspc.ps
 
pstext sources.txt -R  -JM1ch  -N -O -K -D0.1c/0c -F+f10 >> timspc.ps
echo  -68.39064  10.57158  | psxy  -R -J -Sa0.5c -W.7p -N  -K -O -Gred    >>   timspc.ps
 
 
echo  -67.13431  10.67163     Max Mo=4.454e+19Nm | pstext -D1c/0c  -F+f10,Helvetica-Bold -R -J -Wwhite   -N -K -O  >> timspc.ps
 
makecpt -Ccool -T16/76/1    > time.cpt
 
psxy  timspc.dat  -R -J -Sc -Ctime.cpt -W3p+cl -N -V -O -K   >> timspc.ps
 
psscale -D0.5c/5c/7.5c/.5ch -O -Ctime.cpt   -B2:"Rupture Time (sec)":/:: >> timspc.ps
 
psconvert timspc.ps -Tg -P -A -D..\output
