gmtset FORMAT_GEO_MAP D 
pscoast -R-68.49064/-65.77799/10.47158/10.70496  -JM10c -G255/255/204 -Df -W0.7p -P -B0.5  -K -S104/204/255 -Lf-67.13/10.5716/10.59/20+l > beachballs.ps
psxy -R  -JM10c sources.gmt -Sd0.2c   -W1p  -K -O -G255/0/0 >> beachballs.ps
pstext -R  -JM10c sources.txt -N -O -K -F+f10,Helvetica-Bold -D0.1c/0c >> beachballs.ps
echo  -68.39064  10.57158  | psxy  -R -J -Sa0.5c -W.7p -N  -K -O -Gred    >>   beachballs.ps
 
psmeca -R  -JM10c -Sa1.5c beachb.foc -V -O -C1 -N >> beachballs.ps
 
psconvert beachballs.ps -Tg -P -A -D..\output
