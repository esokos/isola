gmtset PLOT_DEGREE_FORMAT D  ANNOT_FONT_SIZE_PRIMARY 12 ANNOT_FONT_SIZE_SECONDARY 12 HEADER_FONT_SIZE 14 LABEL_FONT_SIZE 14
  
gawk "{print $3,$2,1}" selstat.gmt > sta.gmt
gawk "{print $3,$2,11,0,1,\"CB\",$1}" selstat.gmt > tsta.gmt
  
pscoast -R-77.73454/-61.08223/3.99900/20.12680  -JM16c+ -G255/255/204 -Df -W0.7p  -Lf-69.4084/5.1279/12.0629/200+l -B2/2:."Event ID\072260624_22_04_33.00":  -Na/0.8p,red,-.- -K -S104/204/255  > 260624_22_04_33.00_selsta.ps
psxy -R -J  sta.gmt -St.4c -M  -W1p/0 -K -O -G255/0/0 >> 260624_22_04_33.00_selsta.ps
pstext -R -J  tsta.gmt  -D0/0.45c  -W255/255/255,o  -K -O -G0/0/255 >> 260624_22_04_33.00_selsta.ps
psxy -R -J event.gmt -Sa.6c -M  -W1p/0  -O -G255/0/0 >> 260624_22_04_33.00_selsta.ps
  
ps2raster 260624_22_04_33.00_selsta.ps -A -P -Tg
  
del tsta.gmt sta.gmt
  
copy 260624_22_04_33.00_selsta.ps     ..\output\
copy 260624_22_04_33.00_selsta.png     ..\output\
  
