del .gmtdefaults4 .gmtcommands4
gmtset PS_MEDIA A4 FONT_TITLE 18 FONT_LABEL 16 FONT_ANNOT_PRIMARY 12
   
makecpt -Cno_green -T0/100/10 > inv1.cpt
   
psxy   -R0/13/0.09379/0.57952 -JX22c/15c inv1.gmt  -W2.5p,black,- -K -B2g1:"Source number":/0.1g0.1:"Correlation"::."Correlation vs Source number Plot":WeSn > 260624_22_04_33.00_inv_sub3.ps
psmeca -R -J  -Sa1.3c/12 -K -O inv1.foc -V -Zinv1.cpt  >> 260624_22_04_33.00_inv_sub3.ps
psmeca -R -J  -Sa1.3c/12 -K -O inv1.foc -V -T >> 260624_22_04_33.00_inv_sub3.ps
psscale -D25c/4c/8c/0.5c -O -Cinv1.cpt -B::/:DC\045: >> 260624_22_04_33.00_inv_sub3.ps
   
del inv1.cpt inv1.gmt inv1.foc
   
psconvert 260624_22_04_33.00_inv_sub3.ps -Tg -P   -D..\output
