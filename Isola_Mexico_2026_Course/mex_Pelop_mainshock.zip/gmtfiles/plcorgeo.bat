gmtset ANNOT_FONT_SIZE_PRIMARY 11 LABEL_FONT_SIZE 14 PLOT_DEGREE_FORMAT D
gawk "{print $1,$2,$5}" planecorrgeo01.dat >  corcongeo.dat
  
makecpt -Ccopper -T0/100/10 -I > dc.cpt
makecpt -Ccool  -T0/1/0.05     > cr.cpt 
  
pscontour corcongeo.dat -R23.4534/23.8896/36.4847/36.8552 -JM15c -W1p -Ccr.cpt -K -A+a0+s10+p+o+gwhite -I  -B0.1 > planecorrgeo01.ps
  
pscoast -R -J -Wthin -K -O -Df -Lfx2/2/36.6699/5k+l >> planecorrgeo01.ps
  
psxy -R  -J  corcongeo.dat -Sc0.1c   -W1p/0 -K -O -G255/0/0 >> planecorrgeo01.ps
  
  
gawk "{ if ($5>0) print $1,$2,$12,$6,$7,$8,"5","0","0",$3}" planecorrgeo01.dat > testfoc.dat 
psmeca -R -J  -Sa0.35c/12 -O -K testfoc.dat -Zdc.cpt >> planecorrgeo01.ps
  
psmeca -R -J  -Sa0.65c/12 -O -K maxval.foc -Zdc.cpt >> planecorrgeo01.ps
  
psscale -D19c/4c/7c/0.3c -O -Ccr.cpt -K   -B0.1:Correlation: >> planecorrgeo01.ps
psscale -D19c/13c/7c/0.3c -O -Cdc.cpt -K -L  -B::/:DC\045: >> planecorrgeo01.ps
psxy -R -J -Sa0.8c origins.dat -Wthick  -O  >> planecorrgeo01.ps
 
ps2raster planecorrgeo01.ps -Tg -P -A -D..\output
