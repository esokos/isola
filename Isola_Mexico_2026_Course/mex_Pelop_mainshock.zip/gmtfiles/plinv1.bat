del .gmtdefaults4 .gmtcommands4
gmtset PS_MEDIA A4 FONT_TITLE 18 FONT_LABEL 16 FONT_ANNOT_PRIMARY 12
   
makecpt -Cno_green -T0/100/10 > inv1.cpt
   
psxy   -R84/106/0.63667/0.85661 -JX22c/15c inv1.gmt  -W2.5p,black,- -K -B5g1:"Depth (km)":/0.1g0.1:"Correlation"::."Correlation vs Depth Plot":WeSn > 140829_03_45_05.00_inv_sub1.ps
psmeca -R -J  -Sa1.3c/12 -K -O inv1.foc -V -Zinv1.cpt  >> 140829_03_45_05.00_inv_sub1.ps
psmeca -R -J  -Sa1.3c/12 -K -O inv1.foc -V -T >> 140829_03_45_05.00_inv_sub1.ps
psscale -D25c/4c/8c/0.5c -O -Cinv1.cpt -B::/:DC\045: >> 140829_03_45_05.00_inv_sub1.ps
   
psconvert 140829_03_45_05.00_inv_sub1.ps-Tg -P   -D..\output
 copy 140829_03_45_05.00_inv_sub1.ps ..\output
move inv1.cpt ..\gmtfiles
move inv1.gmt ..\gmtfiles
move inv1.foc ..\gmtfiles
move plinv1.bat ..\gmtfiles
