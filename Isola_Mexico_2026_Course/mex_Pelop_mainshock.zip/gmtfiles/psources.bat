gmtset PAPER_MEDIA A4
gmtset PLOT_DEGREE_FORMAT D
pscoast -R23.62743/23.82743/36.56999/36.76999  -JM14c -G255/255/204 -Df -W0.7p  -B0.1 -K -S104/204/255   > sources.ps
psxy -R -J -O  -K      sources.gmt   -S  -G255/0/0    -W1.p -V >> sources.ps 
gawk "{print $1,$2,"14","1","1","1",$5}" sources.gmt > textsou.txt
pstext -R -J -O   textsou.txt  -V >> sources.ps 
