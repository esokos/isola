G:\mex_Pelop\3DPelop_Leonidio_average.cru
