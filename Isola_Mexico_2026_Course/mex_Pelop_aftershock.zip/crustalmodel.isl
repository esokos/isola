F:\isola_EXAMPLE_05\3DPelop_Leonidio_average.cru
