gmtset PLOT_DEGREE_FORMAT D  ANNOT_FONT_SIZE_PRIMARY 12 ANNOT_FONT_SIZE_SECONDARY 12 HEADER_FONT_SIZE 14 LABEL_FONT_SIZE 14
  
gawk "{print $3,$2,1}" selstat.gmt > sta.gmt
gawk "{print $3,$2,11,0,1,\"CB\",$1}" selstat.gmt > tsta.gmt
  
pscoast -R21.72522/25.72301/35.03480/38.16650  -JM16c+ -G255/255/204 -Df -W0.7p  -Lf23.7241/35.254/36.6007/50+l -B0.5/0.5:."Event ID\072140829_03_48_36.00":  -Na/0.8p,red,-.- -K -S104/204/255  > 140829_03_48_36.00_selsta.ps
psxy -R -J  sta.gmt -St.4c -M  -W1p/0 -K -O -G255/0/0 >> 140829_03_48_36.00_selsta.ps
pstext -R -J  tsta.gmt  -D0/0.45c  -W255/255/255,o  -K -O -G0/0/255 >> 140829_03_48_36.00_selsta.ps
psxy -R -J event.gmt -Sa.6c -M  -W1p/0  -O -G255/0/0 >> 140829_03_48_36.00_selsta.ps
  
ps2raster 140829_03_48_36.00_selsta.ps -A -P -Tg
  
del tsta.gmt sta.gmt
  
copy 140829_03_48_36.00_selsta.ps     ..\output\
copy 140829_03_48_36.00_selsta.png     ..\output\
  
