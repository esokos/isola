      program isorand_postproc_gui2

c for step 2
c select VR > threshold


c      parameter (NG=100000)  !10000=max(numpos *numtim) ! numpos, numtime number of positions and times       
c      parameter (NG2=50000)   !200 =max(nsel) ; nsel number of "the best"
c      dimension npert(NG),nsour(NG),ntim(NG),
c     * strg(NG),dipg(NG),rakg(NG),
c     *	 amog(NG),adcg(NG),aclg(NG),avog(NG),varg(NG),
c     *   a1g(NG),a2g(NG),a3g(NG),a4g(NG),a5g(NG),a6g(NG)		  
c      dimension bb(NG2)      
c      dimension sela1(NG2),sela2(NG2),sela3(NG2),
c     *	        sela4(NG2),sela5(NG2),sela6(NG2),
c     *          selamog(NG2),seladcg(NG2),
c     *          selaclg(NG2),selavog(NG2)	 
c      dimension selvarg(NG2),nselnpert(NG2)
c      dimension nselnsour(NG2),nselntim(NG2)	 
	  
c      open(114,file='isorandinp.inp')    ! input
      open(214,file='isorandout.out')    ! input and output !!!!
      open(133,file='CLVDetcPOST.dat')   ! input   
      open(135,file='CLVDetcPOST_BEST.dat') ! output  

      do i=1,7
	  read(214,*) ! skip 7 lines
	  enddo
	  read(214,*) nbestall,varmaxmax 

	  
	  setVRmax=0.9 * varmaxmax
	  
	  ibest2=0
      do i=1,nbestall
C      read(133,'(1x,3i5,2f8.0,6e15.5,10x,1f12.4)') ! error: the last 1f12.4 should be 1e15.5
C      read(133,'(1x,3i5,2f8.0,6e15.5,10x,1e15.5)')
      read(133,*)
     *nselnpert,nselnsour,nselntim,selaclg,selavog,
     *sela1,sela2,sela3,sela4,sela5,sela6,VR	 

      if(VR.ge.setVRmax) then
	  ibest2=ibest2+1
      write(135,'(1x,3i5,2f8.0,6e15.5,10x,1f12.4)') ! caution 
     *nselnpert,nselnsour,nselntim,selaclg,selavog,
     *sela1,sela2,sela3,sela4,sela5,sela6,VR	 
c	  else
	  endif
      enddo

      write(*,*) 'Processing stage 2 (restricted VR)'
      write(*,*) 'CLVDetcPOST.dat  had VRmax= ',varmaxmax
	  write(*,*) 'CLVDetcPOST_BEST.dat has VR> ',setVRmax
	  write(*,*) 'No.of solutions in CLVDetcPOST_BEST.dat= ',ibest2 
      write(*,*) 'CLVDetcPOST_BEST.dat copied in CLVDetcPOST.dat'

      write(214,*)  
      write(214,*) 'Restricting solutions to VR > ', setVRmax 
      write(214,*) 'No.of solutions in CLVDetcPOST_BEST.dat= ',ibest2
      write(214,*) 'CLVDetcPOST_BEST.dat copied in CLVDetcPOST.dat'
	  write(214,*) ibest2,setVRmax 
	  
	  
      close (133);close (135); close(214)
	  
 888  stop
      end
      