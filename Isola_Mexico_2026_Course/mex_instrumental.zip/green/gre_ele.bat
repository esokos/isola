copy src01.dat source.dat
gr_xyz.exe
copy gr.hea gr01.hea
copy gr.hes gr01.hes
    
copy src02.dat source.dat
gr_xyz.exe
copy gr.hea gr02.hea
copy gr.hes gr02.hes
    
copy src03.dat source.dat
gr_xyz.exe
copy gr.hea gr03.hea
copy gr.hes gr03.hes
    
copy src04.dat source.dat
gr_xyz.exe
copy gr.hea gr04.hea
copy gr.hes gr04.hes
    
copy src05.dat source.dat
gr_xyz.exe
copy gr.hea gr05.hea
copy gr.hes gr05.hes
    
copy src06.dat source.dat
gr_xyz.exe
copy gr.hea gr06.hea
copy gr.hes gr06.hes
    
copy src07.dat source.dat
gr_xyz.exe
copy gr.hea gr07.hea
copy gr.hes gr07.hes
    
del gr.hea
del gr.hes
del source.dat
             
rem end with GREEN part
             
rem elementary seismogram part 
             
copy gr01.hes gr.hes
copy gr01.hea gr.hea
elemse.exe
copy elemse.dat ..\invert\elemse01.dat
    
copy gr02.hes gr.hes
copy gr02.hea gr.hea
elemse.exe
copy elemse.dat ..\invert\elemse02.dat
    
copy gr03.hes gr.hes
copy gr03.hea gr.hea
elemse.exe
copy elemse.dat ..\invert\elemse03.dat
    
copy gr04.hes gr.hes
copy gr04.hea gr.hea
elemse.exe
copy elemse.dat ..\invert\elemse04.dat
    
copy gr05.hes gr.hes
copy gr05.hea gr.hea
elemse.exe
copy elemse.dat ..\invert\elemse05.dat
    
copy gr06.hes gr.hes
copy gr06.hea gr.hea
elemse.exe
copy elemse.dat ..\invert\elemse06.dat
    
copy gr07.hes gr.hes
copy gr07.hea gr.hea
elemse.exe
copy elemse.dat ..\invert\elemse07.dat
    
del gr.hea
del gr.hes
del elemse.dat
rem ******************************** 
rem ******************************** 
rem Finished with Green function calculation 
rem close this window and move to inversion. 
