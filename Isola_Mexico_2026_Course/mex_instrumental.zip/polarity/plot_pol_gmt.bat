psmeca ref_mech2.gmt   -R0/10/0/10 -JX17c -Sm15c -K - a0.3c/cc  -ewhite  -t0.1p  -gblack   -W1p -Glightgray -T0 > pol_plot.ps
gawk "{if (NR>1) print $1,$2,$3,$4}" mypol.dat > 4pspolar.txt
pspolar 4pspolar.txt -R -J -N -Ss0.7c  -D5/5  -M15c  -e0.5p  -O -K -T0/0/5/18  >>  pol_plot.ps 
echo .5  2   | psxy -R -J -O  -K -Ss.6c -W0.5p >> pol_plot.ps 
echo .5  1.5 | psxy -R -J -O  -K -Ss.6c  -Gblack  >> pol_plot.ps 
echo .5  1.0 | psxy -R -J -O  -K -Sc.3c  -Gblack  >> pol_plot.ps 
echo .5  0.6 | psxy -R -J -O  -K -Sc.3c    -W0.5p >> pol_plot.ps 
echo 1.0 2.0 12 0 1 CM D, - | pstext -R -J -O  -K >> pol_plot.ps 
echo 1.0 1.5 12 0 1 CM C, + | pstext -R -J -O  -K >> pol_plot.ps 
echo 1.0 1.0 12 0 1 CM P    | pstext -R -J -O  -K >> pol_plot.ps 
echo 1.0 0.6 12 0 1 CM T    | pstext -R -J -O  -K >> pol_plot.ps 
echo 0.4 0.2 12 0 1 LM X - polarity not defined | pstext -R -J -O  -K   >> pol_plot.ps 
echo 0.4 9.5 12 0 1 LM Source depth (km)  8 | pstext -R -J -O     >> pol_plot.ps 
ps2raster pol_plot.ps -A -P -Tg 
