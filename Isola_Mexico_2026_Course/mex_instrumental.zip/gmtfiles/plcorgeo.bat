gmtset ANNOT_FONT_SIZE_PRIMARY 11 LABEL_FONT_SIZE 14 PLOT_DEGREE_FORMAT D
gawk "{print $1,$2,$5}" planecorrgeo01_Depth1.dat >  corcongeo1.dat
gawk "{print $1,$2,$5}" planecorrgeo01_Depth2.dat >  corcongeo2.dat
gawk "{print $1,$2,$5}" planecorrgeo01_Depth3.dat >  corcongeo3.dat
  
makecpt -Ccopper -T0/100/10 -I > dc.cpt
makecpt -Ccool  -T0/1/0.05     > cr.cpt 
  
pscontour corcongeo1.dat -R21.8328/22.0472/38.2649/38.455 -JM7.5c -W1p -Ccr.cpt -K -A+a0+s10+p+o+gwhite -I  -B0.1 > planecorrgeo01.ps
pscoast -R -J -Wthin -K -O -Df -Lfx2/2/38.36/5k+l >> planecorrgeo01.ps
psxy -R  -J  corcongeo1.dat -Sc0.1c   -W1p/0 -K -O -G255/0/0 >> planecorrgeo01.ps
gawk "{ if ($5>0) print $1,$2,$12,$6,$7,$8,"5","0","0",$3}"  planecorrgeo01_Depth1.dat  > testfoc.dat 
psmeca -R -J  -Sa0.35c/12 -O -K testfoc.dat -Zdc.cpt >> planecorrgeo01.ps
psmeca -R -J  -Sa0.65c/12 -O -K maxval.foc -Zdc.cpt >> planecorrgeo01.ps
psxy -R -J -Sa0.8c origins.dat -Wthick  -O -K  >> planecorrgeo01.ps
  
  
  
pscontour corcongeo2.dat -R21.8328/22.0472/38.2649/38.455 -JM7.5c -W1p -Ccr.cpt -A+a0+s10+p+o+gwhite -I -K -O  -X8.5c -B0.1 >> planecorrgeo01.ps
pscoast -R -J -Wthin -K -O -Df -Lfx2/2/38.36/5k+l >> planecorrgeo01.ps
psxy -R  -J  corcongeo2.dat -Sc0.1c   -W1p/0 -K -O -G255/0/0 >> planecorrgeo01.ps
gawk "{ if ($5>0) print $1,$2,$12,$6,$7,$8,"5","0","0",$3}"  planecorrgeo01_Depth2.dat  > testfoc.dat 
psmeca -R -J  -Sa0.35c/12 -O -K testfoc.dat -Zdc.cpt >> planecorrgeo01.ps
psmeca -R -J  -Sa0.65c/12 -O -K maxval.foc -Zdc.cpt >> planecorrgeo01.ps
psxy -R -J -Sa0.8c origins.dat -Wthick  -O -K  >> planecorrgeo01.ps
  
  
  
pscontour corcongeo3.dat -R21.8328/22.0472/38.2649/38.455 -JM7.5c -W1p -Ccr.cpt -A+a0+s10+p+o+gwhite -I -K -O  -X8.5c -B0.1 >> planecorrgeo01.ps
pscoast -R -J -Wthin -K -O -Df -Lfx2/2/38.36/5k+l >> planecorrgeo01.ps
psxy -R  -J  corcongeo3.dat -Sc0.1c   -W1p/0 -K -O -G255/0/0 >> planecorrgeo01.ps
gawk "{ if ($5>0) print $1,$2,$12,$6,$7,$8,"5","0","0",$3}"  planecorrgeo01_Depth3.dat  > testfoc.dat 
psmeca -R -J  -Sa0.35c/12 -O -K testfoc.dat -Zdc.cpt >> planecorrgeo01.ps
psmeca -R -J  -Sa0.65c/12 -O -K maxval.foc -Zdc.cpt >> planecorrgeo01.ps
psxy -R -J -Sa0.8c origins.dat -Wthick  -O -K  >> planecorrgeo01.ps
 
psscale -Dn1.1/0.0+w7c/0.3c -R -J -O -K -Ccr.cpt    -B0.1:Correlation: >> planecorrgeo01.ps
psscale -Dn1.1/1.1+w7c/0.3c -R -J -O    -Cdc.cpt -L -B::/:DC\045: >> planecorrgeo01.ps
 
ps2raster planecorrgeo01.ps -Tg -P -A -D..\output
