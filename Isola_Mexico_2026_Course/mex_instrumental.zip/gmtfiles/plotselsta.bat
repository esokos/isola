gmtset PLOT_DEGREE_FORMAT D  ANNOT_FONT_SIZE_PRIMARY 12 ANNOT_FONT_SIZE_SECONDARY 12 HEADER_FONT_SIZE 14 LABEL_FONT_SIZE 14
  
gawk "{print $3,$2,1}" selstat.gmt > sta.gmt
gawk "{print $3,$2,11,0,1,\"CB\",$1}" selstat.gmt > tsta.gmt
  
pscoast -R21.17630/22.69583/37.73630/38.81600  -JM16c+ -G255/255/204 -Df -W0.7p  -Lf21.9361/37.8119/38.2762/50+l -B0.5/0.5:."Event ID\072210217_03_36_06.30":  -Na/0.8p,red,-.- -K -S104/204/255  > 210217_03_36_06.30_selsta.ps
psxy -R -J  sta.gmt -St.4c -M  -W1p/0 -K -O -G255/0/0 >> 210217_03_36_06.30_selsta.ps
pstext -R -J  tsta.gmt  -D0/0.45c  -W255/255/255,o  -K -O -G0/0/255 >> 210217_03_36_06.30_selsta.ps
psxy -R -J event.gmt -Sa.6c -M  -W1p/0  -O -G255/0/0 >> 210217_03_36_06.30_selsta.ps
  
ps2raster 210217_03_36_06.30_selsta.ps -A -P -Tg
  
del tsta.gmt sta.gmt
  
copy 210217_03_36_06.30_selsta.ps     ..\output\
copy 210217_03_36_06.30_selsta.png     ..\output\
  
