copy gr01.hes gr.hes
copy gr01.hea gr.hea
elemse.exe
copy elemse.dat elemse01.dat
    
copy gr02.hes gr.hes
copy gr02.hea gr.hea
elemse.exe
copy elemse.dat elemse02.dat
    
copy gr03.hes gr.hes
copy gr03.hea gr.hea
elemse.exe
copy elemse.dat elemse03.dat
    
del gr.hea
del gr.hes
del elemse.dat
rem ******************************** 
rem ******************************** 
rem Finished with Green function calculation 
rem you can go on with file copy.... 
