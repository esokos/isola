          
REM needs GRxx.HEA, GRxx.HES for selected source position xx
REM needs ALLSTAT.DAT, MECHAN.DAT, 99.SYN
          
copy gr02.hea gr.hea
copy gr02.hes gr.hes
conshift.exe
REM creates temporary file SXXXROW.DAT for each XXX station.
          
copy  99.syn i.dat
copy  sPAZOIrow.dat row.dat
syn_cor.exe
copy  outsei.dat PAZOI.syn
copy  outsei.dat PAZOIraw.dat
copy  outsei.dat PAZOIsyn.dat
          
copy  99.syn i.dat
copy  sPTEOrow.dat row.dat
syn_cor.exe
copy  outsei.dat PTEO.syn
copy  outsei.dat PTEOraw.dat
copy  outsei.dat PTEOsyn.dat
          
copy  99.syn i.dat
copy  sGRNLrow.dat row.dat
syn_cor.exe
copy  outsei.dat GRNL.syn
copy  outsei.dat GRNLraw.dat
copy  outsei.dat GRNLsyn.dat
          
copy  99.syn i.dat
copy  sPFVIrow.dat row.dat
syn_cor.exe
copy  outsei.dat PFVI.syn
copy  outsei.dat PFVIraw.dat
copy  outsei.dat PFVIsyn.dat
          
          
del i.dat gr.hea gr.hes outsei.dat row.dat
