G:\mex_Portugal_synt\crustal_Portugal.cru
