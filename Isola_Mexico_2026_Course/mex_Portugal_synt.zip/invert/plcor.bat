gmtset ANNOT_FONT_SIZE_PRIMARY 11 LABEL_FONT_SIZE 14 PAPER_MEDIA A4
gawk "{if (NR>2 && $3 > 0)  print $2,15+($1-1)*5,$10,$4,$5,$6,"5","0","0"}" corr01.dat > testfoc.dat
gawk "{if (NR>2)  print $2,15+($1-1)*5,$3}" corr01.dat > corcon.dat
makecpt -Ccopper -T0/100/10 -I > dc.cpt
makecpt -Ccool -T0/0.0985/0.02   > cr.cpt
pscontour corcon.dat -R14.7/25.3/14.5/25.5  -W0.5p -JX21c/18c -B1g1:"Time(sec)":/1:"Source position (km)":WeSn -Ccr.cpt -K -I -A+a0+s10 > corr01.ps
psscale -D22c/4c/7c/0.2 -O -Ccr.cpt -K -L -B:Correlation: >> corr01.ps
psscale -D22c/13c/7c/0.2 -O -Cdc.cpt -K -L  -B::/:DC\045: >> corr01.ps
psmeca -R -JX21c/18c -Sa0.35 -O -K testfoc.dat -Zdc.cpt >> corr01.ps
psmeca -R -JX21c/18c -Sa0.65 -O maxval.foc -Zdc.cpt >> corr01.ps
ps2raster corr01.ps -Tg -P -E75 -Qg2  -Qt2 -D..\output
move /y ..\output\corr01.png  ..\output\230107_18_40_47.40_corr01.png
