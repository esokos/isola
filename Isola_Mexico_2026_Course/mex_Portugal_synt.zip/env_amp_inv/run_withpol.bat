echo off
del inv1.dat
del inv2.dat
del out6_opt.dat
echo on
 
  newaspo.exe 
