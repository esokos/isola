gmtset PLOT_DEGREE_FORMAT D  ANNOT_FONT_SIZE_PRIMARY 12 ANNOT_FONT_SIZE_SECONDARY 12 HEADER_FONT_SIZE 14 LABEL_FONT_SIZE 14
  
gawk "{print $3,$2,1}" selstat.gmt > sta.gmt
gawk "{print $3,$2,11,0,1,\"CB\",$1}" selstat.gmt > tsta.gmt
  
pscoast -R-9.73400/-8.36900/36.93283/38.62467  -JM16c+ -G255/255/204 -Df -W0.7p  -Lf-9.0515/37.0513/37.7788/50+l -B0.5/0.5:."Event ID\072230107_18_40_47.40":  -Na/0.8p,red,-.- -K -S104/204/255  > 230107_18_40_47.40_selsta.ps
psxy -R -J  sta.gmt -St.4c -M  -W1p/0 -K -O -G255/0/0 >> 230107_18_40_47.40_selsta.ps
pstext -R -J  tsta.gmt  -D0/0.45c  -W255/255/255,o  -K -O -G0/0/255 >> 230107_18_40_47.40_selsta.ps
psxy -R -J event.gmt -Sa.6c -M  -W1p/0  -O -G255/0/0 >> 230107_18_40_47.40_selsta.ps
  
ps2raster 230107_18_40_47.40_selsta.ps -A -P -Tg
  
del tsta.gmt sta.gmt
  
copy 230107_18_40_47.40_selsta.ps     ..\output\
copy 230107_18_40_47.40_selsta.png     ..\output\
  
