gawk "{if (NR>1) print $1,$2,$3,$4}" mypol.dat > 4pspolar.txt
