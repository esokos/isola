call "C:\Program Files (x86)\Intel\oneAPI\setvars.bat"
isorand_main_gui.exe
isorand_postproc_gui.exe
done.exe
