%% isorand_postproc_gui.m

%% Open files
fid114 = fopen('isorandinp.inp', 'r');
if fid114 == -1, error('isorandinp.inp NOT FOUND'); end

fid111 = fopen('inv111.dat', 'r');
fid122 = fopen('CLVDetc.dat', 'r');
fid214 = fopen('isorandout.out', 'w');
fid133 = fopen('CLVDetcPOST.dat', 'w');

%% Read isorandinp.inp
fgetl(fid114); % Skip 1st line
numper = fscanf(fid114, '%d', 1);
fprintf('numper = %d\n', numper);
fprintf(fid214, 'numper= %d\n', numper);

fgetl(fid114); fgetl(fid114); % Skip lines
is_data = fscanf(fid114, '%d %d %d', 3);
ismin = is_data(1); ismax = is_data(2); isstep = is_data(3);
numpos = fix((ismax - ismin) / isstep) + 1;
fprintf('numpos = %d\n', numpos);
fprintf(fid214, 'numpos= %d\n', numpos);

fgetl(fid114); fgetl(fid114); % Skip lines
shift_data = fscanf(fid114, '%f %f %f', 3);
shiftMIN = shift_data(1); shiftMAX = shift_data(2); dt = shift_data(3);
numtim = fix(shiftMAX/dt) - fix(shiftMIN/dt) + 1;
fprintf('numtim = %d\n', numtim);
fprintf(fid214, 'numtim= %d\n', numtim);

numsol = numpos * numtim;
fprintf('numsol = %d\n', numsol);
fprintf(fid214, 'numsol= %d\n', numsol);

% Find 10% of solutions
nsel = fix(double(numsol) / 10.0);
if nsel > floor(numsol/2), nsel = floor(numsol/2); end
% if nsel > NG2
%     error('STOP problem DIM nsel: %d', nsel);
% end
fprintf('nsel = %d\n', nsel);
fprintf(fid214, 'nsel= %d\n', nsel);

%% Main Loop (Perturbations)
if numper == 0, numper = 1; end
nbestall = 0;
varmaxmax = 0;

for ip = 1:numper
    % initialize 
    npert = zeros(numsol,1); nsour = zeros(numsol,1); ntim = zeros(numsol,1);
    amog = zeros(numsol,1); adcg = zeros(numsol,1); aclg = zeros(numsol,1); 
    avog = zeros(numsol,1); varg = zeros(numsol,1);
    a_coeffs = zeros(numsol, 6); % a1g to a6g
    
ig = 0;
    for iss = 1:numpos
        for ii = 1:numtim
            ig = ig + 1;
            
            % read inv111.dat
            line111 = fgetl(fid111);
            if ischar(line111) && ~isempty(strtrim(line111))
                data111 = sscanf(line111, '%f');
                if length(data111) >= 11
                    npert(ig) = data111(1); 
                    nsour(ig) = data111(2); 
                    ntim(ig) = data111(3);
                    amog(ig) = data111(7); 
                    adcg(ig) = data111(8); 
                    aclg(ig) = data111(9);
                    avog(ig) = data111(10); 
                    varg(ig) = data111(11);
                end
            end
            
            % read CLVDetc.dat
            line122 = fgetl(fid122);
            if ischar(line122) && ~isempty(strtrim(line122))
                data122 = sscanf(line122, '%e');
                if length(data122) >= 11
                    a_coeffs(ig, :) = data122(6:11)';
                end
            end
        end
    end
    % Find (varlim) for the nsel best solutions
    % Use sort
    sorted_varg = sort(varg, 'descend');
    varlim = sorted_varg(nsel);
    varmax = sorted_varg(1);
    
    if varmax > varmaxmax, varmaxmax = varmax; end
    
    % Select nsel best solutions
    ibest = 0;
    for i = 1:numsol
        if varg(i) >= varlim && varg(i) <= varmax
            ibest = ibest + 1;
            
            % Write to  CLVDetcPOST.dat (Unit 133)
            % Format: 3i5, 2f8.0, 6e15.5, 1f12.4
            fprintf(fid133, ' %4d %4d %4d %7.0f %7.0f %14.5e %14.5e %14.5e %14.5e %14.5e %14.5e %11.4f\n', ...
                npert(i), nsour(i), ntim(i), aclg(i), avog(i), ...
                a_coeffs(i,1), a_coeffs(i,2), a_coeffs(i,3), ...
                a_coeffs(i,4), a_coeffs(i,5), a_coeffs(i,6), varg(i));
        end
    end
    nbestall = nbestall + ibest;
end

%% Final messages
fprintf('No. of solutions in CLVDetcPOST.dat= %d\n', nbestall);
fprintf(fid214, 'No. of solutions in CLVDetcPOST.dat= %d\n', nbestall);
fprintf('Max VR over all perturbations= %.4f\n', varmaxmax);
fprintf(fid214, 'Max VR over all perturbations= %.4f\n', varmaxmax);
fprintf(fid214, ' %d %.4f\n', nbestall, varmaxmax);
fprintf('End\n');

%% Close files
fclose('all');