copy GRNLres.dat GRNLsyn.dat
copy PAZOIres.dat PAZOIsyn.dat
copy PFVIres.dat PFVIsyn.dat
copy PTEOres.dat PTEOsyn.dat