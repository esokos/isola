G:\mex_Portugal_real\crustal_Portugal.cru
