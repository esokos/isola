gmtset PLOT_DEGREE_FORMAT D  ANNOT_FONT_SIZE_PRIMARY 12 ANNOT_FONT_SIZE_SECONDARY 12 HEADER_FONT_SIZE 14 LABEL_FONT_SIZE 14
  
gawk "{print $3,$2,1}" selstat.gmt > sta.gmt
gawk "{print $3,$2,11,0,1,\"CB\",$1}" selstat.gmt > tsta.gmt
           
pscoast -R-9.72700/-8.37600/36.87446/38.68304  -JM16c+ -G255/255/204 -Df -W0.7p  -Lf-9.2445/36.9649/37.5204/70+l -B0.2/0.5:."Event ID\072230107_18_40_47.40":  -Na/0.8p,red,-.- -K -S104/204/255  > 230107_18_40_47.40_stasol.ps
           
psxy -R -J  sta.gmt -St.4c -M  -W1p/0 -K -O -G255/0/0 >>  230107_18_40_47.40_stasol.ps
pstext -R -J  tsta.gmt  -D0/0.45c  -W255/255/255,o  -K -O  -G0/0/255 >> 230107_18_40_47.40_stasol.ps
           
psxy -R -J ..\gmtfiles\notusedstat.gmt -St.4c  -W1p/0 -K  -O -G138/138/138 >> 230107_18_40_47.40_stasol.ps
           
psxy -R -J event.gmt -Sa.6c -M  -W1p/0 -K -O -G255/0/0 >> 230107_18_40_47.40_stasol.ps
           
psmeca -R -J 230107_18_40_47.40 -Sa1.5c  -O  >> 230107_18_40_47.40_stasol.ps
           
ps2raster 230107_18_40_47.40_stasol.ps -A -P -Tg 
           
del tsta.gmt sta.gmt 
  
copy 230107_18_40_47.40_stasol.ps   ..\output\
copy 230107_18_40_47.40_stasol.png  ..\output\
  
