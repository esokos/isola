 function [freq,sp] = my_tapered_spectrum(dt,x)
 % name is not very good; this is spectrum of tapered signal, not tapered spectrum
      fs=1/dt;
      numpo=length(x);
      last=numpo; % FFT assumes x is of an EVEN  length;
      if mod(last,2) ~= 0; % if modulo us not equal 0, we have an ODD number 
      last=numpo-1;     % making an EVEN length
      end
      x=x(1:last);
      
      % TAPER used only for resulting spectra of records and synth mice
      x=x .* tukeywin(length(x),0.2); % tapering only for computation of spectrum
      % fixed option = 0.2, i.e., tapering 20% of total legth; 10% at each end 

      
      xdft = fft(x); 
      xdft = xdft(1:length(x)/2+1); %length(x) je pocet bodu x a take xdft
      freq = 0:fs/length(x):fs/2; % from 0 with step df=1/T=1/(Ndt) to Nyquist (1/(2dt)), all in Hz
      sp=(1/fs) * abs(xdft); % 1/fs= dt MULTIPLICATION BY DT IS A MUST
end
 
 
 