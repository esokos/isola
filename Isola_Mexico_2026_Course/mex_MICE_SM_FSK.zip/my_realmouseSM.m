close all
clear all

% Detection of Mice I on 3-component SM accelerograph
% Jiri Zahradnik, summer 2026


set(0, 'DefaultAxesFontName', 'Arial'); % Sets font for axes, labels, titles
set(0, 'DefaultTextFontName', 'Arial'); % Sets font for other text objects
set(0, 'DefaultAxesFontSize', 14);      % Sets default axes font size
set(0, 'DefaultTextFontSize', 16);      % Sets default general text size
set(0,'DefaultFigureColormap',feval('jet')); %  Sets default colormap


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%           READING INPUT DATA 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


[C] = textread('Invert.dat','%f','commentstyle','matlab'); 
endtime=C(1)
pwavetime=C(2)
% swavetime=C(3)
% timlim=C(4)
%perctaper=C(5)

[D] = textread('Statinfo.dat','%s' ,'commentstyle','matlab') % comments start with % 
sigfilename=D{1}
insfilename=D{2}

%compstr=zeros(4,1);
compstr=['t','N','E','Z'];


% Reading single-station real record %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 3-comp RECORD to be analyzed (t,N,E,Z)
A = load(sigfilename); 
dt=A(2,1)-A(1,1) % column 1 of A is time in seconds; starting at 0
totlen=(length(A)-1)*dt


if(endtime>totlen)
    disp('WARNING: endtime>totlen')
    pause
end


% Reading instrumental gain (assuming flat acc. response down f=0)
fid = fopen(insfilename,'r');
count2ground= str2num(fgetl(fid))
fclose(fid);


% Creating synthtic data set = integrated acceleration 
% % Producing acc reord corresponing to various non-unit steps in acc on N,E,Z, all occuring at here fixed time swavetime 
% % Not used in real-data processing 
% swavetime=200   % here fixed for 
% t=(0:dt:endtime+dt)'; % column vector
% y=zeros(size(t));
% idx = t >= swavetime & t <= endtime+dt; % Apply piecewise definition
% y(idx) = t(idx) - swavetime; % integrated acc record
% %size(y)
% t2=(0:dt:endtime)'; % column vector
% y2=diff(y) ./dt;                 %  acc record CAUTION diff on 1...N makes file 1... N-1 
% yN=y2 .* 2 ./ count2ground;      % now y2, yN, etc are from 0 to endtime; is non-int acc record in COUNTS
% yE=y2 .* -4 ./ count2ground;     % values 2, -4, -20 are true acc steps in m/s2
% yZ=y2 .* -20 ./ count2ground;
% %    figure (200)
% %    hold on
% %    plot(t2,yN)
% %    plot(t2,yE)
% %    plot(t2,yZ)
% %    title('Synth acc. records for testing, 3 comp.') % Does not contain transient signal, only steps 
% %    legend
 
   
  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% PROCESSING and INVERTING REAL DATA in a loop over components 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

disp(['Best-fit model of SM record: ',  sigfilename])  
%disp('Shift in multiples of dt, Mouse I and II in units given by valmax')  

fid2=fopen('MouseFit.dat', 'w'); % write at the end of next loop
fprintf(fid2,'%6s %',['Best-fit model of SM record: ',  sigfilename ]);
fprintf(fid2,'\n');
 

valmax=zeros(4,1);   %pre-allocating for maximumum of components; column 2,3,4 = comp N,E,Z
truemax1=zeros(4,1); %pre-allocating for size of Mouse I on components

 for icolumn=2:1:4       % SUPERLOOP OVER COMPONENTS of SIGNAL (=REAL RECORD) 2,3,4 = N,E,Z
 
ilft=1; irgh=round(endtime/dt)  + 1; % this is index, not last time, therefore "+ 1"
x=A(ilft:irgh,1);       % time  from 0 to endtime, step dt
y=A(ilft:irgh,icolumn); % THREE  components


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % % This part should be active only for performing test with (above created) synthtic acc. data
% % % Otherwise should be commented out

% if icolumn ==2
% y=yN;
% end
% if icolumn ==3
% y=yE;
% end
% if icolumn ==4
% y=yZ;
% end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

 L=length(y); 
%size(y) % y is 1 column vector
tt =  (1:L)' ;           % 1D column vector of indices for time vector tt (whole record!)

% Demean 
%mean calculated from noise window
L2=round((pwavetime-0.1*pwavetime)/dt)  ;   % reserve 10% to define noise window before P
%%%L2=floor( 90/dt) ; 
y=y-mean(y(1:L2)); %  mean removed from whole record


% Plotting original records
figure (20)
specstring = strcat('SIGNAL',' ',compstr(icolumn));
plot(x,y,'DisplayName',specstring,'LineWidth',3)
xlabel('time (s)')
ylabel('acceleration (count)')
title ('Original record, non-normalized') 
legend
hold on



% % %Normalization of a particular COMPONENT (in a loop) after demean, BEFORE integration (good)
[out,ii]  = max(abs(y)); % normalization IS NOT NEEDED (IN PRINCIPLE) but we use it
%normtime=ii*dt
y=y/out;  % normalization differs among components; makes y dimensionless
%out
valmax(icolumn)=out * count2ground;  % normalization constant of a component, inlcuding conversion count to m/s2
% units of out is count; units of y is 1; 
%units of count2ground is (m/s2)/count; unites of valmax is m/s2
%%valmax(icolumn)=out * count2ground  / 10 ; % normalization constant and conversion count to m/s2 radians
% Here remembering normalization and  conversion, both applied later in DEnormlaization

%Possibility: In later code versions it could be better to define
%valmax(icolumn)=out; just like that. And to operate with count2ground separately. 
%Because count2ground is used only in numeric ouput, not during inversion.  

figure (21)
specstring = strcat('SIGNAL',' ',compstr(icolumn));
plot(x,y,'DisplayName',specstring,'LineWidth',3)
xlabel('time (s)')
ylabel('normalized acceleration (dimensionless)')
title ('Original acc. record, normalized') 
legend
hold on


% % % % Integration (demean and detrend always before integration)  
y_int = cumsum(y,1) *dt; % integrated normalzied acc' units of y_int is second
%y_int=detrend(y_int); % works well for APE !!!!!! should not be used for DRO

dataobs=y_int; % integrated normalized acc. record renamed; unit is second

% TUKEY's window
% this is not needed
%Matlab2024b has no function "taper" but has tukeywin
%%%%% dataobs=dataobs .* tukeywin(length(dataobs),2*perctaper); %at each end, taper width is perctaper (now fixed at 0.05)
% tukeywin needs specification of DOUBLE length 2*perctaper (now fixed at % 0.1 = 10% of total)
  
%Plotting total integrated record (no end cuts)
figure (32)
specstring = strcat('SIGNAL',' ',compstr(icolumn));
plot(x,dataobs,'DisplayName',specstring,'LineWidth',3)
xlabel('time (s)')
ylabel('integrated norm. acc. (s)')
title ('Integrated acc. record') % differs from SIGNAL if taper is applied
legend
hold on


%  ***************** INVERSION *********************
% Seeking two linear segments and breakpoint
   
   % Given: y (column), dt, t4
t = (0:dt:endtime)'; 
y = dataobs(:);        

% --- Step 1: Smooth to get baseline ---
% Choose window length >> period of deterministic signal
% win = 100 %???    201;  % adjust based on your sampling and signal
% y_base = movmean(y, win);   % or sgolayfilt(y,3,201), etc. Smoothed integrated SM record = baseline (variable)
y_base=y;

% --- Step 2: breakpoint search on on y_base ---
N = length(t);
errors = inf(N,1);
slope1 = zeros(N,1);
slope2 = zeros(N,1);
%j=0; % to count passes through grid search 
 loopstep=floor(N/50); % To make process faster; step is not 1, but step = 2% of full length 
  
for k = 3:loopstep:N-3      % grid search of breakpoint
%    j=j+1;
    t_break = t(k);

    tL = t(1:k);
    bL = y_base(1:k);
    p1 = polyfit(tL, bL, 1);
    s1 = p1(1);

    tR = t(k:end);
    bR = y_base(k:end);

    y_break = s1*t_break + p1(2);
    s2 = ( (tR - t_break) \ (bR - y_break) );

    slope1(k) = s1;
    slope2(k) = s2;

    gL = s1*tL + p1(2);
    gR = y_break + s2*(tR - t_break);
    gk = [gL; gR(2:end)];

%    errors(k) = sum((gk - y_base).^2);
    errors(k) = norm(gk - y_base)/norm(y_base);

end
%   j % total number of passes through the grid-search loop

% Evaluation of grid search, seeking best-fit solution (per components) 
[minmis, k_best] = min(errors);
t_star = t(k_best);
s1 = slope1(k_best);
s2 = slope2(k_best);
slopediff=s2-s1; % differential slope (better than slope 2 if slope 1 is non-zero)


% Rebuild g(t) with continuity = the best-fit solution = fitted Mouse I
tL_best = t(1:k_best);
bL_best = y_base(1:k_best);
p1_best = polyfit(tL_best, bL_best, 1);
b1 = p1_best(2);
y_break = s1*t_star + b1;

g = zeros(size(t));
idxL = t <= t_star;
idxR = t >  t_star;
g(idxL) = s1*t(idxL) + b1;
g(idxR) = y_break + s2*(t(idxR) - t_star);

% --- Step 3: plot ---
% figure (35); hold on;
% plot(t, y, 'Color', [0.6 0.6 1]);          % raw
% plot(t, y_base, 'b', 'LineWidth', 1.5);    % baseline
% plot(t, g, 'r--', 'LineWidth', 2);         % model
% legend('int. SM record', 'smoothed int. SM record', 'fitted mice I');
% xlabel('time (s)')
% grid on;

   %%% Plotting waveforms
   %%% y_base ... "Signal" is INTEGRATED RECORD of real seismic signal PLUS a mouse
   %%% g  ... ...  "Mouse"  is synthtic mouse (integrated acc. step) best-fitted to the "Signal"
   %%% Each component has its own normalization and conversion from counts to ground motion was not made 
   figure (36)
   hold on
   if(icolumn==2)
   xline(pwavetime, 'b','DisplayName','Pwavetime'); 
   end
    specstring = strcat('SIGNAL',' ',compstr(icolumn));
    plot(t,y_base, 'DisplayName',specstring);
    specstring = strcat('MOUSE',' ',compstr(icolumn));
    plot(t,g,'DisplayName',specstring,'LineWidth',3)
   %legend ('Location', 'northwest')
   legend
   title(['Modeling record: ', sigfilename])
   xlabel('time (s)')
   ylabel('integrated norm. acc. (s)')

   
%%%%% Mouse removal on integrated record (subtraction)
  y_corr_int=y_base - g; % unit is second
  figure (37)
   hold on
    specstring = strcat('SIGNAL',' ',compstr(icolumn));
    plot(t,y_corr_int, 'DisplayName',specstring);
   legend
   title(['Corrected integrated record: ', sigfilename])
   xlabel('time (s)') 
   ylabel('integrated norm. acc. (s)')
   
   
%%%%% Back to correcetd (non-integrated) acceleration record and
%%%%% denormalization of components and result will be in counts
   y_corr = diff(y_corr_int) ./ dt; %unit is 1
   y_corr (numel(y_corr) + 1) = 0;  % zero padded because diff shortend time series by 1 sample
   y_corr = y_corr .* (valmax(icolumn) ./ count2ground); % unit is count
% division by count2ground is because valmax includes this factor, but it
% was not applied; % records were normalized but remained in counts
% Factor with which components of non-integrated acc were initially
% normalized was this (valmax(icolumn) ./ count2ground), having unit = count

  figure (38)
   hold on
    specstring = strcat('SIGNAL',' ',compstr(icolumn));
    plot(t,y_corr, 'DisplayName',specstring);
   legend
   title(['Corrected non-int denorm. acc. record', sigfilename])
   xlabel('time (s)') 
   ylabel('integrated denorm. acc. (count)')
   

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Numeric output (screen and file) [within loop over components ]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% DEnormalization: Caution; each component has its own norlaization constant 
% Unit step in acc. produces unit slope in integrated acc.
% Here we do two things; respecting that each component had different formal
% normalization (due to its peak), and use slopes in the integraed acc. to infer abolsute step 
% in acc. from slope (= acc. step), converting counts to m/s2. This is use in NUMERIC output only.

     truemax1(icolumn)=slopediff * valmax(icolumn); % Identified Mouse I size on SM = acc. step; unit is m/s2

  %header 1
 fprintf(fid2,'\n');
 fprintf(fid2,'%6s %','component');
 fprintf(fid2,'%6s %', compstr(icolumn));
 fprintf(fid2,'\n');
  fprintf(     '\n');
 fprintf(     '%6s %','component');
 fprintf(     '%6s %', compstr(icolumn));
 fprintf(     '\n');
%header 2
header_fmt = '%15s %15s %15s\n';
%name1= 'iter.no.';
name2= 'breakpoint (s)';
name4= 'acc. step (m/s2)';
name6= 'misfit';
fprintf(fid2, header_fmt, name2, name4, name6); % in file 
fprintf(      header_fmt, name2, name4, name6); % on screen
%values
data_fmt = '%15.6f %15.6e %15.6f\n';



fprintf(      data_fmt, t_star,  truemax1(icolumn), minmis);
fprintf(fid2, data_fmt, t_star,  truemax1(icolumn), minmis);




   %%%%%%%% Plottng spectra (all after integration and component normalization) 
   %%% "Signal" is INTEGRATED RECORD of real seismic signal PLUS a possible real mouse
   %%% "Mouse"  is synthtic mouse (integrated acc. step) best-fitted to the "Signal"
   %%% Each component has its own normalization and conversion from counts  to ground-motion was not made 
      [freq,sp]=my_tapered_spectrum(dt,y_base);
      %length(d)
      %[freq,sp]=my_tapered_spectrum(dt,d_int);
      spSIGplot=sp;    %   /max(sp);  % /sp(1,1); %
      figure (40)
      specstring = strcat('SIGNAL',' ',compstr(icolumn));
      loglog(freq,spSIGplot, 'DisplayName',specstring);
      hold on
      [freq,sp]=my_tapered_spectrum(dt,g);
      %length(dbest)
      %[freq,sp]=my_tapered_spectrum(dt,dbest_int);
      spMICEplot=sp;    %   /max(sp);  % /sp(1,1); %
      specstring = strcat('Mouse',' ',compstr(icolumn));
      loglog(freq,spMICEplot, 'DisplayName',specstring,'LineWidth',3);
      legend
      xlim ([1e-3, 1e0])
      ylim ([1e-4, 1e2])
      xlabel('frequency (Hz)')
      ylabel('spectrum of norm. int. acc. (s^2)')
      title (['Modeling spectrum: ', sigfilename])

  % spectra of corrected and uncorrected integrated acc    
      [freq,sp]=my_tapered_spectrum(dt,y_base);
      %length(d)
      %[freq,sp]=my_tapered_spectrum(dt,d_int);
      spSIGplot=sp;    %   /max(sp);  % /sp(1,1); %
      figure (41)
      specstring = strcat('SIGNAL',' ',compstr(icolumn));
      loglog(freq,spSIGplot, 'DisplayName',specstring);
      hold on
      [freq,sp]=my_tapered_spectrum(dt,y_corr_int);
      %length(dbest)
      %[freq,sp]=my_tapered_spectrum(dt,dbest_int);
      spMICEplot=sp;    %   /max(sp);  % /sp(1,1); %
      specstring = strcat('Signal-corrceted',' ',compstr(icolumn));
      loglog(freq,spMICEplot, 'DisplayName',specstring,'LineWidth',3);
      legend
      xlim ([1e-3, 1e0])
      ylim ([1e-4, 1e2])
      xlabel('frequency (Hz)')
      ylabel('spectrum of norm. int. acc. (s^2)')
      title (['Modeling corrected spectrum: ', sigfilename])

      
      
      % Analyze where signal and mouse spectra of a given component significantly differ
      % Increase continually freq and seek first point where sp of 'signal' is > 10 * mouse
     nfreq=numel(freq);
     df=freq(2)-freq(1);
     for ifr= 1:1:nfreq
        if spSIGplot(ifr) > 10 .* spMICEplot(ifr) 
        %fprintf('Stopping at index %d\n', ifr);
        fprintf('Stopping at frequency (Hz) %d\n', ifr*df);
        break;
        end
     end


       
 % Some interpretation
   if abs(s2)/abs(s1) <= 5 
       msg5 = 'Slope 2 not much (5-times) larger than slope1. No large acc. step found on this component.\n';
       fprintf(fid2,msg5);
       fprintf(     msg5);
   end
  
   if minmis > 0.5
       msg6 = 'WARNING: Misfit on this component is high, > 0.5, i.e. VR < 0.5; inversion may be wrong.\n';
       fprintf(fid2,msg6);
       fprintf(     msg6);
   end

  
 
end    %%%%%%%   END OF SUPERLOOP OVER COMPONENTS of REAL RECORD (processing and inversion)
 fclose (fid2);

 
 % Saving output plots and files
  
   fname = ['Mice_Record_', sigfilename(1:end-4),'.png'];
   saveas(figure(36), fullfile(pwd, 'Mice_plots', fname));
   fname = ['Mice_Spectrum_', sigfilename(1:end-4),'.png'];
   saveas(figure(40), fullfile(pwd, 'Mice_plots', fname));

   
      
src  = 'MouseFit.dat';
filen= ['Mice_Fit_', sigfilename(1:end-4),'.dat']; 
dest = fullfile('mice_plots', filen);
copyfile(src, dest);

src  = 'Invert.dat';
filen= ['Invert_', sigfilename(1:end-4),'.dat']; 
dest = fullfile('mice_plots', filen);
copyfile(src, dest);

src  = 'Statinfo.dat';
filen= ['Statinfo_', sigfilename(1:end-4),'.dat']; 
dest = fullfile('mice_plots', filen);
copyfile(src, dest);


 disp(' ')
 disp('Code terminated')
 
 
 
 
 
 
 function [freq,sp] = my_tapered_spectrum(dt,x)
 % name is not very good; this is spectrum of tapered signal, not tapered spectrum
      fs=1/dt;
      numpo=length(x);
      last=numpo; % FFT assumes x is of an EVEN  length;
      if mod(last,2) ~= 0; % if modulo us not equal 0, we have an ODD number 
      last=numpo-1;     % making an EVEN length
      end
      x=x(1:last);
      
      % TAPER used only for resulting spectra of records and synth mice
      x=x .* tukeywin(length(x),0.2); % tapering only for computation of spectrum
      % fixed option = 0.2, i.e., tapering 20% of total legth; 10% at each end 

      
      xdft = fft(x); 
      xdft = xdft(1:length(x)/2+1); %length(x) je pocet bodu x a take xdft
      freq = 0:fs/length(x):fs/2; % from 0 with step df=1/T=1/(Ndt) to Nyquist (1/(2dt)), all in Hz
      sp=(1/fs) * abs(xdft); % 1/fs= dt MULTIPLICATION BY DT IS A MUST
end
 
 
 
 
 