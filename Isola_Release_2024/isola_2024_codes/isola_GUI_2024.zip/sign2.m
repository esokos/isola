function AA = sign2(A,B)

  if B >=0
      AA=abs(A);
  else
      AA=-abs(A);
  end