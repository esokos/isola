function chi = calc_chi(corr_opt,corr_iso,ndf)


chi=((1-corr_iso^2)/(1-corr_opt^2))*ndf


