function hinv = cov_triv(nsampl,datafiles)
%This function makes a simple calculation of Covariance matrix
%
%
nsampl3=3*nsampl; % 3 components

speye=sparse(eye(nsampl3));

hinv=[];

%% load datafiles
for ii=1:length(datafiles)
   file=['.\invert\' datafiles{ii} 'raw.dat'];
   st=load(file);
   maxst=max(max(st(:,2:4)));    % max of all 3 components 
   %maxst^2; % value of Cd for station (anal. of vardat)
 
   hinv1=speye/maxst^2; % 1st station
   hinv=blkdiag(hinv,hinv1); % accumulate matrix per station ;
  % whos
   clear hinv1 st maxst
end

%%
%figure % no. 3: Cd-1  (sparse) after threshold
%spy(hinv)
% imagesc(hinv)

%% Printing  Cd-1 into a file (in sparse mode)
disp('Be patient ! Printing Cd-1')
fid=fopen('hinv.dat','w');
[i,j,s] = find(hinv); % detekuje nenulove prvky a dava je do vektoru s, indexy do vektoruu i a j
%[i,j,s]; % this screen print is OK but i,j have exp. format
for k=1:size(i)  % this print in loop has correct format
    fprintf(fid,'%i %i %e \n',i(k),j(k),s(k,1));
end
%% type hinv.dat % this would print on screen
disp ('hinv.dat created = Cd-1')
fclose(fid);

disp ('All done !')

 
end

