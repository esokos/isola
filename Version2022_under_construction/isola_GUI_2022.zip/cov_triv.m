function hinv = cov_triv(nsampl,datafiles,filew)
% This function makes a simple calculation of Covariance matrix  final output will be the inverted matrix of covariance
% Input
% datafiles is a matrix with station names 
% e.g. datafiles={'DSF','EFP','GUR'};  this defines the number of stations
% code expects the DSFraw.dat file etc...
%  
% nsampl=number of samples e.g. 1024
%
% filew=1 or 0 write or not write the hinv.dat  file
%
% Output
% the inverted matrix is returned as output !!
%
% Example
% datafiles={'ANX','DRO','GUR'}; (raw files must be in same folder)
% cov_triv(1024,datafiles,1);
%
% Nov 2021
%
%
% BE CAREFUL as it is now the second station is divided by 100 !!!
%
%%  
nsampl3=3*nsampl; % 3 components
speye=sparse(eye(nsampl3));
hinv=[];

%% load datafiles
for ii=1:length(datafiles)
   file=[datafiles{ii} 'raw.dat'];
   st=load(file);
   maxst=max(max(st(:,2:4)));    % max of all 3 components 
   %maxst^2; % value of Cd for station (anal. of vardat)
   if ii==2
       hinv1=speye/100*(maxst^2);   %%%%% BE CAREFUL
   else
       hinv1=speye/maxst^2; % 1st station     
   end
  
   hinv=blkdiag(hinv,hinv1); % accumulate matrix per station ;
  % whos
   clear hinv1 st maxst
end

%%
%figure % no. 3: Cd-1  (sparse) after threshold
%spy(hinv)
imagesc(hinv)

%% output  %% Printing  Cd-1 into a file (in sparse mode)
if filew == 1
    
  disp('Be patient ! Printing Cd-1')
  fid=fopen('hinv.dat','w');
  [i,j,s] = find(hinv); % detekuje nenulove prvky a dava je do vektoru s, indexy do vektoruu i a j
  %[i,j,s]; % this screen print is OK but i,j have exp. format
  for k=1:size(i)  % this print in loop has correct format
    fprintf(fid,'%i %i %e \n',i(k),j(k),s(k,1));
  end
 % type hinv.dat % this would print on screen
  disp ('hinv.dat created = Cd-1')
  fclose(fid);
  disp ('All done !')
else
    disp ('output in file is not needed !')
end
%%

 
end

